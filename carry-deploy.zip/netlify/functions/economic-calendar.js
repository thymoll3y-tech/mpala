// Netlify Function: economic-calendar
//
// Thin server-side proxy for the JBlanked Forex Factory calendar API.
// Exists because that API requires an Authorization header (Api-Key),
// which browsers can't reliably send cross-origin, and because it
// keeps the API key out of the client-side bundle entirely.
//
// SETUP:
// 1. Get a free API key from https://www.jblanked.com/profile/ (after
//    creating a free account) — look for "API Key" / "Generate Key".
// 2. In the Netlify dashboard for this site, go to:
//    Site configuration -> Environment variables -> Add a variable
//    Key:   JBLANKED_API_KEY
//    Value: <your key>
// 3. Deploy. Netlify auto-detects /netlify/functions and deploys this
//    as /.netlify/functions/economic-calendar
//
// USAGE FROM THE APP:
//   fetch('/.netlify/functions/economic-calendar')
//   -> { events: [ {Name, Currency, Impact, Date, Actual, Forecast, Previous, ...}, ... ] }
//
// Free tier on JBlanked is 1 request/day — this function does NOT
// add its own caching (Netlify Functions are stateless/serverless),
// so the CLIENT must cache the response (e.g. localStorage, ~12-24h)
// and only call this endpoint once a day to stay within that limit.

const UPSTREAM_URL = 'https://www.jblanked.com/news/api/forex-factory/calendar/week/?currency=USD';

exports.handler = async function (event, context) {
  const apiKey = process.env.JBLANKED_API_KEY;

  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Cache-Control': 'no-store',
  };

  if (!apiKey) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'JBLANKED_API_KEY is not configured on the server.',
        hint: 'Add it under Netlify Site configuration -> Environment variables, then redeploy.',
      }),
    };
  }

  try {
    const upstreamRes = await fetch(UPSTREAM_URL, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Api-Key ${apiKey}`,
      },
    });

    const text = await upstreamRes.text();

    if (!upstreamRes.ok) {
      return {
        statusCode: upstreamRes.status,
        headers,
        body: JSON.stringify({
          error: `Upstream error ${upstreamRes.status}`,
          detail: text.slice(0, 500),
        }),
      };
    }

    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      return {
        statusCode: 502,
        headers,
        body: JSON.stringify({
          error: 'Upstream returned non-JSON response',
          detail: text.slice(0, 500),
        }),
      };
    }

    // Normalize to { events: [...] } regardless of whether upstream
    // returns a bare array or an object.
    const eventsArray = Array.isArray(data) ? data : (data.events || data.data || []);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ events: eventsArray, fetchedAt: Date.now() }),
    };
  } catch (err) {
    return {
      statusCode: 502,
      headers,
      body: JSON.stringify({ error: 'Fetch to upstream failed', detail: String(err && err.message || err) }),
    };
  }
};
